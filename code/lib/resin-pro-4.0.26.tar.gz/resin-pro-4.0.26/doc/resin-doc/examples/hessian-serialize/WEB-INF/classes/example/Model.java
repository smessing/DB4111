package example;

public enum Model {
  CIVIC,
  PRIUS,
  MUSTANG,
  EDSEL,
  MODEL_T
}

