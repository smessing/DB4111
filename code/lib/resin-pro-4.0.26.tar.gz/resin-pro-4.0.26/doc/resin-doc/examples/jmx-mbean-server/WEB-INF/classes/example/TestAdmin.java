package example;

/**
 * Management interface for the basic MBean.
 */
public interface TestAdmin {
  /**
   * Gets the data value.
   */
  public String getData();
}
