<h1>Test Resource</h1>

PHP: <?= java_bean("testResource") ?>

<ul>
<li><a href="test">Test Servlet</a>
<li><a href="index.jsp">Test JSP</a>
</ul>

