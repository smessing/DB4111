<?php
/*
 * server-side PHP code for the websocket
 */

$ws = websocket_start("websocket-handler.php");

