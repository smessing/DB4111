package example;

/**
 * The Greeting service returns a simple string.
 */
public interface GreetingAPI {
  /**
   * Returns the greeting string.
   */
  public String greeting();
}
