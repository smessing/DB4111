//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by setup.rc
//
#define IDD_SETUP_INIT                  106
#define IDC_RESIN_HOME                  1000
#define IDC_APACHE_HOME                 1001
#define IDC_APACHE_ENABLE               1002
#define IDC_IIS_HOME                    1003
#define IDC_IIS_ENABLE                  1004
#define IDC_OK                          1005
#define IDC_CANCEL                      1006
#define IDC_APPLY                       1007
#define IDC_APACHE                      1010
#define IDC_IIS                         1011
#define IDC_BUTTON2                     1012
#define IDC_NEXT                        1013
#define IDC_BUTTON4                     1014
#define IDC_REMOVE                      1030
#define IDC_NETSCAPE_ENABLE             1031
#define IDC_NETSCAPE_HOME               1032
#define IDC_WEBSITE_ENABLE              1033
#define IDC_WEBSITE_HOME                1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
